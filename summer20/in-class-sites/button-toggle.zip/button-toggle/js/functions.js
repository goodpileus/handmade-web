function menuShow() {
  var box = document.getElementById("box");
  box.classList.toggle("open");
}
