$("button").click(
    function(){
        $(".box").toggleClass("dark");
    }
);
